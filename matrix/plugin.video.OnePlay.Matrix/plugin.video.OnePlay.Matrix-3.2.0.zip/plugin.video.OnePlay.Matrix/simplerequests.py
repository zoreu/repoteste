# -*- coding: utf-8 -*-
import requests
import json as json_
import hashlib
import os
import pickle
import time
from pathlib import Path
from helper import profile



class client_requests:
    def __init__(self, proxy=None, cache_dir=os.path.join(profile, 'cache'), cache_ttl=3600):
        self.session = requests.Session()
        self.proxy = proxy
        self.user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
        self.cache_dir = cache_dir
        self.cache_ttl = cache_ttl  # Tempo de vida do cache em segundos (1 hora por padrão)
        
        # Criar diretório de cache se não existir
        Path(self.cache_dir).mkdir(parents=True, exist_ok=True)
        
        if proxy:
            self.session.proxies = {
                'http': proxy,
                'https': proxy
            }

    def _generate_cache_key(self, method, url, headers=None, data=None):
        """Gera uma chave única para o cache com base na requisição."""
        headers = headers or {}
        data = data or b""
        key_string = f"{method}:{url}:{json_.dumps(headers, sort_keys=True)}:{data}"
        return hashlib.sha256(key_string.encode()).hexdigest()

    def _get_cache(self, cache_key):
        """Recupera a resposta do cache, se existir e não estiver expirada."""
        cache_file = Path(self.cache_dir) / cache_key
        if not cache_file.exists():
            return None

        try:
            with open(cache_file, 'rb') as f:
                cached = pickle.load(f)
            
            timestamp, response_text = cached['timestamp'], cached['response_text']
            
            # Verificar se o cache expirou
            if time.time() - timestamp > self.cache_ttl:
                cache_file.unlink()  # Agora o arquivo já foi fechado
                return None
            
            return response_text
        except (pickle.PickleError, KeyError, FileNotFoundError):
            return None


    def _set_cache(self, cache_key, response_text):
        """Armazena a resposta no cache."""
        cache_file = Path(self.cache_dir) / cache_key
        try:
            with open(cache_file, 'wb') as f:
                pickle.dump({
                    'timestamp': time.time(),
                    'response_text': response_text
                }, f)
        except (pickle.PickleError, OSError) as e:
            print(f"Erro ao salvar no cache: {e}")

    def request(self, method, url, headers=None, data=None, stream=False):
        headers = headers or {'User-Agent': self.user_agent}
        
        # Gerar chave do cache
        cache_key = self._generate_cache_key(method, url, headers, data)
        
        # Verificar cache apenas se não for stream
        if not stream:
            cached_response = self._get_cache(cache_key)
            if cached_response is not None:
                print(f"Retornando resposta do cache para {url}")
                # Criar um objeto Response simulado para compatibilidade
                response = requests.models.Response()
                response._content = cached_response.encode()
                response.status_code = 200
                return response

        try:
            response = self.session.request(method, url, headers=headers, data=data, stream=stream, timeout=60)
            
            # Armazenar no cache apenas se a requisição for bem-sucedida e não for stream
            if not stream and response.status_code == 200:
                self._set_cache(cache_key, response.text)
            
            return response
        except requests.exceptions.RequestException as e:
            print(f"Erro na requisição: {e}")
            return None

    def get(self, url, headers=None, stream=False):
        return self.request('GET', url, headers=headers, stream=stream)

    def post(self, url, data=None, json=None, headers=None):
        headers = headers or {'User-Agent': self.user_agent}
        if json:
            data = json_.dumps(json)
            headers['Content-Type'] = 'application/json'
        return self.request('POST', url, headers=headers, data=data)


class simplerequests:
    @classmethod
    def get(cls, url, headers=None, stream=False, proxy=None):
        if proxy:
            proxy = 'http://' + proxy if not 'http' in proxy else proxy
            if proxy.endswith('/'):
                proxy = proxy[:-1]
        client = client_requests(proxy=proxy)
        return client.get(url, headers=headers, stream=stream)
    
    @classmethod
    def post(cls, url, data=None, json=None, headers=None, proxy=None):
        if proxy:
            proxy = 'http://' + proxy if not 'http' in proxy else proxy
            if proxy.endswith('/'):
                proxy = proxy[:-1]        
        client = client_requests(proxy=proxy)
        return client.post(url, data=data, json=json, headers=headers)

